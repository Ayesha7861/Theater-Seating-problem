package com.demo.theater.main;

import java.util.List;
import java.util.Scanner;

import com.demo.theater.repository.TheaterProcessRequest;
import com.demo.theater.repository.TheaterRepositoryService;
import com.demo.theater.repository.TheaterRequestService;
import com.demo.theater.vo.TheaterLayout;
import com.demo.theater.vo.TheaterRequest;

/**
 * Check Request ends with "end"
 * Construct Theater Layout
 * Construct Theater Request
 * Process Request and Allocate Seats
 * @author Ayesha
 *
 */
public class SeparateLayoutAndRequest {
	
	public  Scanner readInputData(Scanner input) {
		String line;
        StringBuilder layout = new StringBuilder();
        StringBuilder ticketRequests = new StringBuilder();
        boolean isLayoutFinished = false;
		 while((line = input.nextLine()) != null && !line.equals("end")){
	        	
	            if(line.length() == 0){
	                isLayoutFinished = true;
	                continue;
	            }
	            if(!isLayoutFinished){
	                layout.append(line + System.lineSeparator());
	            }else{
	                ticketRequests.append(line + System.lineSeparator());
	                
	            }
	        }
		 	System.out.println("Theater layout -->\n"+layout); 
		 	System.out.println("Tickets Request  -->\n"+ticketRequests); 
	        input.close();
	        
	        /*
	         * To Construct Theater Layout.
	         */
	        TheaterRepositoryService theaterRepository = new TheaterRepositoryService();
	        TheaterLayout theaterLayout = theaterRepository.addTheaterLayout(layout.toString());
	        /*
	         * To Construct Theater Request.
	         */
	        TheaterRequestService theaterRequestService = new TheaterRequestService();
	        List<TheaterRequest> requests = theaterRequestService.addTicketRequests(ticketRequests.toString());
	        /**
	         * Process Request and Allocate Seats.
	         */
	        TheaterProcessRequest processRequest = new TheaterProcessRequest();
	        processRequest.processTicketRequests(theaterLayout,requests);
	       
		return input;
	}


}
