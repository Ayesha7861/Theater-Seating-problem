/**
 * 
 */
package com.demo.theater.main;

import java.util.Scanner;

/**
 * Takes Input Data from console
 * 
 * @author Ayesha
 *
 */
public class TheaterSeat {

	public static void main(String[] args) {

		System.out
				.println("Please enter TheaterLayout and TicketRequests and then enter 'end'.\n");

		Scanner input = new Scanner(System.in);

		SeparateLayoutAndRequest layoutAndRequest = new SeparateLayoutAndRequest();

		input = layoutAndRequest.readInputData(input);
		input.close();

	}

}
