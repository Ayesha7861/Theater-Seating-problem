/**
 * 
 */
package com.demo.theater.handler;

import java.util.List;

import com.demo.theater.vo.FindRow;
import com.demo.theater.vo.TheaterLayout;
import com.demo.theater.vo.TheaterSection;

/**
 * Interface for TheaterLayout
 * @author Ayesha
 *
 */
public interface TheaterLayoutHandler {
	
	public TheaterLayout addTheaterLayout(String rawLayout);
	
	public TheaterLayout updateTheaterLayout(TheaterLayout theaterLayout);

	public TheaterLayout deleteTheaterLayout();
	
	public List<TheaterLayout> getTheaterLayout();
	
	public FindRow findSectionByAvailableSeats(List<TheaterSection> sections, int availableSeats);
	
}
