/**
 * 
 */
package com.demo.theater.handler;

import java.util.List;

import com.demo.theater.vo.TheaterRequest;

/**
 * Inteface For TheaterRequest
 * @author Ayesha
 *
 */
public interface TheaterRequestHandler {
	
	public List<TheaterRequest> addTicketRequests(String ticketRequests);

}
