package com.demo.theater.repository;

import java.util.List;

import com.demo.theater.vo.FindRow;
import com.demo.theater.vo.TheaterLayout;
import com.demo.theater.vo.TheaterRequest;
import com.demo.theater.vo.TheaterSection;

/**
 * Processing the input Request , allocates Seats based on Conditions. 
 * 1.Validate The input request.
 * 2.Filling as many orders as possible.
 * 3.Check for Completed Request to avoid duplicate Request processing.
 * 
 * @author Ayesha
 *
 */
public class TheaterProcessRequest {
	
	 public void processTicketRequests(TheaterLayout layout, List<TheaterRequest> requests){
		 
		 TheaterRepositoryService theaterRepository = new TheaterRepositoryService();
		 
		 
		for(int i=0 ; i<requests.size() ; i++){
				 TheaterRequest theaterRequest = requests.get(i);
				 /**
				  * Validating Request
				  */
				 boolean validationInputRequest = validatingRequest(theaterRequest,layout);
				 
				
			if(validationInputRequest){
				
				 List<TheaterSection> sections = layout.getSections();
				 for(int j=0 ; j<sections.size() ; j++){
					 TheaterSection section = sections.get(j);
					 boolean completed = theaterRepository.findComplementRequest(requests, section.getAvailableSeats() - theaterRequest.getNoOfTickets(), i);
					
					 if(completed){
						 System.out.println(theaterRequest.getName()+" Sorry Cannot process Same request");
						 break;
					 }else{
						 
						/*				 		 /**
						  * Filling as many orders as possible
						  */
						 FindRow indexNumber = theaterRepository.findSectionByAvailableSeats(layout.getSections(), theaterRequest.getNoOfTickets());
			                
			                //Update Layout.
			                if(indexNumber != null){
			                	 TheaterSection confirmedTheaterSection = sections.get(indexNumber.getRowNu());
			                	theaterRepository.updateTheaterLayout(layout);
			                	theaterRequest.setRowNumber(confirmedTheaterSection.getRowNumber());
			                	theaterRequest.setSectionNumber(confirmedTheaterSection.getSectionNumber());
			                	confirmedTheaterSection.setAvailableSeats(confirmedTheaterSection.getAvailableSeats() - theaterRequest.getNoOfTickets());
			                	layout.setAvailableSeats(layout.getAvailableSeats() - theaterRequest.getNoOfTickets());
			                	theaterRequest.setCompleted(true);
			                	System.out.println(theaterRequest.getStatus());
			   				 	
			                	
			                	break;
			                }//End of If block
			                else{
			                	System.out.println(theaterRequest.getName()+" Call to split party.");
			                	break;
			                }
					 }
							
				 }
			 }
			 
		 }
	        
	      
	 }

	


/**
 * Validating Request based on TheaterRequest and TheaterLayout,
 * 
 * @param theaterRequest
 * @param layout
 * @return
 */
	private boolean validatingRequest(TheaterRequest theaterRequest,
			TheaterLayout layout) {
		if(theaterRequest.getNoOfTickets() > layout.getAvailableSeats()){
			 System.out.println(theaterRequest.getName()+" Sorry, we can't handle your party");
			 return false;
			 
		 }
		
		if(theaterRequest.getNoOfTickets() < 0){
			System.out.println(theaterRequest.getStatus());
			 return false;
		}
		return true;
	}

}
