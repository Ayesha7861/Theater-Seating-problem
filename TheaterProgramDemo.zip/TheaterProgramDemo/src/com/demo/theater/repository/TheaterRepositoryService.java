/**
 * 
 */
package com.demo.theater.repository;

import java.util.ArrayList;
import java.util.List;

import com.demo.theater.handler.TheaterLayoutHandler;
import com.demo.theater.vo.FindRow;
import com.demo.theater.vo.TheaterLayout;
import com.demo.theater.vo.TheaterRequest;
import com.demo.theater.vo.TheaterSection;

/**
 * TheaterRepositoryService
 * @author Ayesha
 *
 */
public class TheaterRepositoryService implements TheaterLayoutHandler{

	/**
	 * Construct TheaterLayout
	 */
	@Override
	public TheaterLayout addTheaterLayout(String rawLayout) {
        
        TheaterLayout theaterLayout = new TheaterLayout();
        TheaterSection section;
        List<TheaterSection> sectionsList = new ArrayList<TheaterSection>();
        int totalCapacity = 0, value;
        String[] rows = rawLayout.split(System.lineSeparator());
        String[] sections;
        int index = 0;
        for(int i=0 ; i<rows.length ; i++){
            
            sections = rows[i].split(" ");
            
            for(int j=0 ; j<sections.length ; j++){
            
                try{
                
                    value = Integer.valueOf(sections[j]);
                    
                }catch(NumberFormatException nfe){
                    
                    throw new NumberFormatException("'" + sections[j] + "'" + " is invalid section capacity. Please correct it.");
                    
                }
                
                totalCapacity = totalCapacity + value;
                
                section = new TheaterSection();
                section.setRowNumber(i + 1);
                section.setSectionNumber(j + 1);
                section.setCapacity(value);
                section.setAvailableSeats(value);
                section.setIndexNumber(index);
                sectionsList.add(section);
                index++;
                
            }

        }
        
        theaterLayout.setTotalCapacity(totalCapacity);
        theaterLayout.setAvailableSeats(totalCapacity);
        theaterLayout.setSections(sectionsList);
        
        return theaterLayout;
        
    }

	/**
	 * Update TheaterLayout
	 */
	@Override
	public TheaterLayout updateTheaterLayout(TheaterLayout theaterLayout) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Delete TheaterLayout
	 */
	@Override
	public TheaterLayout deleteTheaterLayout() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Get TheaterLayout
	 */
	@Override
	public List<TheaterLayout> getTheaterLayout() {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	/**
	 * findSectionByAvailableSeats based on AvailableSeats
	 */
	
	@Override
	public FindRow findSectionByAvailableSeats(List<TheaterSection> sections,
			int availableSeats) {
		TheaterSection theaterSection = new TheaterSection();
		theaterSection.setAvailableSeats(availableSeats);
		FindRow findRow=null;
		
		for(TheaterSection theaterSection1 : sections){
			if(theaterSection1.getAvailableSeats() >= availableSeats){
				findRow = new FindRow();
				findRow.setRowNu(theaterSection1.getIndexNumber());
				findRow.setSectionNu(theaterSection1.getSectionNumber());
				break;
				
			}
		}
		return findRow;
	}
	
	/**
	 * Find Completed Request to avoid Duplicate request processing.
	 * @param requests
	 * @param complementSeats
	 * @param currentRequestIndex
	 * @return
	 */

	public boolean findComplementRequest(List<TheaterRequest> requests,
			int complementSeats, int currentRequestIndex) {

		for (int i = currentRequestIndex + 0; i < requests.size(); i++) {

			TheaterRequest request = requests.get(i);

			for (TheaterRequest re : requests) {
				if (request.getName().equalsIgnoreCase(re.getName())
						&& request.getNoOfTickets() == re.getNoOfTickets()) {
					if (re.isCompleted())
						return true;
					else
						return false;
				} else
					continue;
			}
		}

		return false;
	}
	
	
}
