/**
 * 
 */
package com.demo.theater.repository;

import java.util.ArrayList;
import java.util.List;

import com.demo.theater.handler.TheaterRequestHandler;
import com.demo.theater.vo.TheaterRequest;

/**
 * @author 978789
 *
 */
public class TheaterRequestService implements TheaterRequestHandler{

	@Override
	public List<TheaterRequest> addTicketRequests(String ticketRequests) {
        
        List<TheaterRequest> requestsList = new ArrayList<TheaterRequest>();
        TheaterRequest request;
        
        String[] requests = ticketRequests.split(System.lineSeparator());
        
        for(String r : requests){
            
            String[] rData = r.split(" ");
            
            request = new TheaterRequest();
            
            request.setName(rData[0]);
            
            try{
                request.setNoOfTickets(Integer.valueOf(rData[1]));
                
            }catch(NumberFormatException nfe){
                
                throw new NumberFormatException("'" + rData[1] + "'" + " is invalid ticket request. Please correct it.");
            }
            request.setCompleted(false);
            
            requestsList.add(request);
            
        }
        
        return requestsList;
        
    }
	
	
	

}
