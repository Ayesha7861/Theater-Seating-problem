/**
 * 
 */
package com.demo.theater.vo;

import java.io.Serializable;
import java.util.List;

/**
 * @author Ayesha
 *
 */
public class TheaterLayout implements Serializable{
	private static final long serialVersionUID = 1L;
	private int totalSeats;
	private int availableSeats;
	List<TheaterSection> sections ;

	public int getTotalCapacity() {
		return totalSeats;
	}

	public void setTotalCapacity(int totalCapacity) {
		this.totalSeats = totalCapacity;
	}

	public int getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

	 public List<TheaterSection> getSections() {
	        return sections;
	    }

	    public void setSections(List<TheaterSection> sections) {
	        this.sections = sections;
	    }
	    
}
