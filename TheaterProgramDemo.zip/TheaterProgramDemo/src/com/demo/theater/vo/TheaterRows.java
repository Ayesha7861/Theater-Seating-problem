/**
 * 
 */
package com.demo.theater.vo;

import java.io.Serializable;
import java.util.List;

/**
 * @author Ayesha
 *
 */
public class TheaterRows implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	List<TheaterSection> theaterSections ;

	/**
	 * @return the theaterSections
	 */
	public List<TheaterSection> getTheaterSections() {
		return theaterSections;
	}

	/**
	 * @param theaterSections the theaterSections to set
	 */
	public void setTheaterSections(List<TheaterSection> theaterSections) {
		this.theaterSections = theaterSections;
	}
	

}
