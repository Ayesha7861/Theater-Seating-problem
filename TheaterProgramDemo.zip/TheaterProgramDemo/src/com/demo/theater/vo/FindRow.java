/**
 * 
 */
package com.demo.theater.vo;

import java.io.Serializable;

/**
 * @author Ayesha
 *
 */
public class FindRow implements Serializable{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int rowNu;
	    private int sectionNu;
		/**
		 * @return the rowNu
		 */
		public int getRowNu() {
			return rowNu;
		}
		/**
		 * @param rowNu the rowNu to set
		 */
		public void setRowNu(int rowNu) {
			this.rowNu = rowNu;
		}
		/**
		 * @return the sectionNu
		 */
		public int getSectionNu() {
			return sectionNu;
		}
		/**
		 * @param sectionNu the sectionNu to set
		 */
		public void setSectionNu(int sectionNu) {
			this.sectionNu = sectionNu;
		}
	    
	    

}
